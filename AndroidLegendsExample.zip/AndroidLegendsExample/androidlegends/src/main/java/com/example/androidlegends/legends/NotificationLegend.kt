package com.example.android_bleed.android_legends.legends

import android.app.Application

abstract class NotificationLegend(application: Application) : AndroidLegend(mApplication = application) {
}