package com.example.android_bleed.android_legends.utilities

import com.example.android_bleed.android_legends.legends.AndroidLegend

object CurrentLegendManager {
    var sCurrentLegend: AndroidLegend? = null
}